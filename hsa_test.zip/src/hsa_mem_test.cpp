#include <string>
#include <iostream>
#include <vector>
#include "hsa_test.h"

int gMemNum; int gMemId = 3;

using namespace std;

enum AllocateEnum 
{
	AllocateNoFlags = 0,
	AllocateRestrict = (1 << 0),    // Don't map system memory to GPU agents
	AllocateExecutable = (1 << 1),  // Set executable permission
	AllocateDoubleMap = (1 << 2),   // Map twice VA allocation to backing store
	AllocateDirect = (1 << 3),      // Bypass fragment cache.
};

uint64_t system_region;
uint64_t kernarg_region;
uint64_t local_region;
uint64_t gpu_local_region;

void mem_alloc_test()
{
	AllocateEnum alloc_flags; // �û�����ʱ����

	vector<HsaMemoryProperties> mem_props(gMemNum);
	hsaKmtGetNodeMemoryProperties(gNodeId, gMemNum, &mem_props[0]);
	printf("node %d has %d mem, chose %d mem\n", gNodeId, gMemNum, gMemId);

	HsaMemoryProperties mem_prop = mem_props[0];
	HsaMemFlags mem_flag;
	HsaMemMapFlags map_flag;

	size_t virtual_size;
	size_t physical_size;
	size_t GPU_VM_SIZE = (1ULL << 40);
	size_t LINUX_64_VM_SIZE = (0x800000000000);

	if (mem_prop.HeapType == HSA_HEAPTYPE_SYSTEM) 
	{
		system_region ;
	}

	/*if (flags & HSA_REGION_GLOBAL_FLAG_COARSE_GRAINED) {
		if (host_accessible_region) {
			dispatch->SetLocalRegion(region);
		}
		else {
			dispatch->SetGPULocalRegion(region);
		}
	}

	if (flags & HSA_REGION_GLOBAL_FLAG_KERNARG) {
		dispatch->SetKernargRegion(region);
	}*/

	physical_size = mem_prop.SizeInBytes;
	if (mem_prop.HeapType == HSA_HEAPTYPE_FRAME_BUFFER_PRIVATE)
	{
		printf("local memory.\n");
		mem_flag.ui32.PageSize = HSA_PAGE_SIZE_4KB;
		mem_flag.ui32.NoSubstitute = 1;
		mem_flag.ui32.HostAccess = 0;
		mem_flag.ui32.NonPaged = 1;
		map_flag.ui32.PageSize = HSA_PAGE_SIZE_4KB;
		virtual_size = GPU_VM_SIZE;
	}
	else if(mem_prop.HeapType == HSA_HEAPTYPE_FRAME_BUFFER_PUBLIC)
	{
		printf("local memory.\n");
		mem_flag.ui32.PageSize = HSA_PAGE_SIZE_4KB;
		mem_flag.ui32.NoSubstitute = 1;
		mem_flag.ui32.HostAccess = 1;
		mem_flag.ui32.NonPaged = 1;
		map_flag.ui32.PageSize = HSA_PAGE_SIZE_4KB;
		virtual_size = GPU_VM_SIZE;
	}
	else if (mem_prop.HeapType == HSA_HEAPTYPE_SYSTEM)
	{
		printf("system memory.\n");
		mem_flag.ui32.PageSize = HSA_PAGE_SIZE_4KB;
		mem_flag.ui32.NoSubstitute = 1;
		mem_flag.ui32.HostAccess = 1;
		mem_flag.ui32.CachePolicy = HSA_CACHING_CACHED;
		map_flag.ui32.HostAccess = 1;
		map_flag.ui32.PageSize = HSA_PAGE_SIZE_4KB;
		virtual_size = LINUX_64_VM_SIZE;
	}

	printf("physical size: %ld.\n", mem_prop.SizeInBytes);
	printf("virtual size: %ld.\n", virtual_size);
	printf("page size: %d.\n", mem_flag.ui32.PageSize);
	printf("page size: %d.\n", map_flag.ui32.PageSize);


	mem_flag.ui32.ExecuteAccess = (alloc_flags & AllocateExecutable ? 1 : 0);
	mem_flag.ui32.AQLQueueMemory = (alloc_flags & AllocateDoubleMap ? 1 : 0);
	float *test_mem;
	HSAKMT_STATUS status = hsaKmtAllocMemory(gNodeId, 1024, mem_flag, (void**)&test_mem);
}

void hsa_mem_test()
{
	printf("\n***********************\n");
	hsa_test_open();
	/* ģ�� hsa_memory_allocate() <hsa.cpp>
	 hsa_memory_allocate() --> core::Runtime::runtime_singleton_->AllocateMemory() <runtime.cpp>
	 region->Allocate() <amd_memory_region.cpp>
	*/
	mem_alloc_test();
}